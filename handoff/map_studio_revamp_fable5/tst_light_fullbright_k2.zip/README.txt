tst_light fullbright KOTOR2 test module

Install:
1. Copy tst_light.mod into your Knights of the Old Republic II Modules folder.
   Steam default: C:\Program Files (x86)\Steam\steamapps\common\Knights of the Old Republic II\Modules
2. Start KOTOR2 and load a save.
3. Open the console and run: warp tst_light

Notes:
- This is the fixed-lighting KOTOR2 test map.
- ARE lighting is fullbright.
- Runtime MDL light nodes were neutralized to avoid the dynamic/shadow light crash seen during testing.
- If the game closes while taking screenshots, disable overlays such as Discord/Steam overlay and retry; that was separate from the map-load crash.

SHA256: a88230bd515dc9e14d2ab55b56d1599160982a6c5eb52cf1a664237eeaa15ab8
Size: 63436 bytes
